# Jakarta EE - Logistics Center - Server - Template Application

This is a template server application. It should be used as a starting point.

Run the Server with:

Maven:
```
mvn clean package wildfly:dev
```

or in Eclipse:
```
Project -> Run As -> (create a Maven run configuration with the same goal)
```
If you work in and start the server in Eclipse (maven run configuration with the same goal) code changes will be updated directly to the server.

