# Jakarta EE - Logistics Center - Client - Template Application

This is a template client application. It should be used as a starting point.

Run the Server with:

Maven:
```
mvn clean package
java -jar ./target/st.cbse.LogisticsCenter.client.jar
```

or in Eclipse:
```
Client.java -> Run As -> Run Application
```
