package st.cbse.productionFacility.productionManagerComponent.data;

public class ProductionManager {
    private String email;
    private String password;

    public ProductionManager() {
    }

    public ProductionManager(String email, String password) {
        this.email = email;
        this.password = password;
    }
}
