package st.cbse.productionFacility.step.data;

public enum StepStatus {
	PENDING,
	IN_PROGRESS,
	FINISHED 
}
