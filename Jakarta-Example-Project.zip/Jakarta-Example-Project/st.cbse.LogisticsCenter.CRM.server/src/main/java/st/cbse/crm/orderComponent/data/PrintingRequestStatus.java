package st.cbse.crm.orderComponent.data;

public enum PrintingRequestStatus {
	CREATED,
	IN_PROD,
	IN_STORAGE
}
