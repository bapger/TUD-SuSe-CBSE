package st.cbse.productionFacility.step.data;

public enum StepType {
	PRINTING_3D,
	PAINTING,
	ENGRAVING,
	SMOOTHING,
	PACKAGING
}
