package st.cbse.crm.orderComponent.data;

public class Engraving extends Option {

	public Engraving(String text, String font, String imagePath) {
		// TODO Auto-generated constructor stub
	}

}
