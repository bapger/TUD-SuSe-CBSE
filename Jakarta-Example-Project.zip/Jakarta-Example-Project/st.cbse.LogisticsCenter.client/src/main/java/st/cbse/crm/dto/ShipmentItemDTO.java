package st.cbse.crm.dto;

public class ShipmentItemDTO {

	public Object getPrintRequestId() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getOrderId() {
		// TODO Auto-generated method stub
		return null;
	}

}
