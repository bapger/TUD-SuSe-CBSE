package st.cbse.crm.orderComponent.data;

public enum OrderStatus {
    CREATED,
    COMPLETED,
    IN_PROD,
    FINISHED,
    SHIPPED,
    REJECTED
}
