package st.cbse.crm.orderComponent.data;

public class Smoothing extends Option {

	public Smoothing(String granularity) {
		// TODO Auto-generated constructor stub
	}

}
