package st.cbse.crm.managerComponent.data;

public class Manager {
    private String email;
    private String password;

    public Manager() {}
    public Manager(String email, String password) {
        this.email = email;
        this.password = password;
    }
	public Object getPassword() {
		// TODO Auto-generated method stub
		return null;
	}
}

