package st.cbse.crm.orderComponent.data;


public class PaintJob extends Option {
    private String color;

    public PaintJob(String colour, int layers) {}

}
