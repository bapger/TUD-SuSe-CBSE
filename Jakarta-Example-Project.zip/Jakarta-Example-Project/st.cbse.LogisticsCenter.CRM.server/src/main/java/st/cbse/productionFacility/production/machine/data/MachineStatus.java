package st.cbse.productionFacility.production.machine.data;

public enum MachineStatus {
    AVAILABLE,
    RESERVED,
    ACTIVE,
    PAUSED
}