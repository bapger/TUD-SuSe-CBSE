package st.cbse.crm.orderComponent.data;

import java.time.LocalDateTime;

public class Invoice {

	public void setPaymentRef(String txnRef) {
		// TODO Auto-generated method stub
		
	}

	public void setPaidDate(LocalDateTime now) {
		// TODO Auto-generated method stub
		
	}

}
