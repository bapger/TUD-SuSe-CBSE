package st.cbse.crm.orderComponent.data;

public enum OrderStatus {
    CREATED,
    COMPLETED,
    VALIDATED,
    SHIPPED,
    REJECTED, FINISHED
}
